package demo1;

public class Enemy {
    private int health;
    private int posX;
    private int posY;

    public void setInitPos(int x, int y) {
        this.posX = x;
        this.posY = y;
    }

    public void setHealth(int initHealth) {
        this.health = initHealth;
    }

    public int getPosX() {
        int tempPosX = this.posX;
        return tempPosX;
    }

    public int getPosY() {
        int tempPosY = this.posY;
        return tempPosY;
    }

    public int getHealth() {
        int tempHealth = this.health;
        return tempHealth;
    }

    public void takeDamage(int dmg) {
        if (dmg >= 0) {
            int tempHealth = this.health - dmg;
            this.health = tempHealth;
        }
    }

    public void attack(Player target) {
        int dmg = 10;
        target.takeDamage(dmg);
    }
}